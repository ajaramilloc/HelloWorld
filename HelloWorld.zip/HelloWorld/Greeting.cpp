#include "Greeting.h"
#include <ctime>
#include <sstream>

Greeting::Greeting(const std::string& name) : TheName(nombre) {}

std::string Greeting::getDate() const {
    std::time_t currentTime = std::time(nullptr);
    std::tm* localDate = std::localtime(&currentTime);

    std::ostringstream dateStream;
    dateStream << (localDate->tm_year + 1900) << "-"
                << (localDate->tm_mon + 1) << "-"
                << localDate->tm_mday;

    return dateStream.str();
}

std::string Greeting::generateMessage() const {
    std::ostringstream menssage;
    message << "Hola Mundo. Saludo de " << TheName
            << " hoy " << getDate() << " .";
    return menssage.str();
}
