#ifndef GREETING_H
#define GREETING_H

#include <string>

class Saludo {
private:
    std::string Thename;

public:
    Saludo(const std::string& name);
    std::string getDate() const;
    std::string generateMessage() const;
};

#endif
