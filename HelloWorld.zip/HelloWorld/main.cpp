#include <iostream>
#include "Greeting.h"

int main() {
    std::string name = "Alejandro Jaramillo Castellanos";
    Saludo saludo(name);

    std::cout << saludo.generarMensaje() << std::endl;

    return 0;
}