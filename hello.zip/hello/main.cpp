#include <iostream>
#include "Greeting.h"

int main() {
    Greeting greeting;
    std::cout << greeting.getGreeting() << std::endl;
    return 0;
}
